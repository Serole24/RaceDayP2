namespace RaceDayAPI.Models;
public class Enrolment { public int EnrolmentId {get;set;} public int UserId {get;set;} public User? User {get;set;} public int CategoryId {get;set;} public Category? Category {get;set;} public int BibNumber {get;set;} public DateTime EnrolledAt {get;set;}=DateTime.UtcNow; public string Status {get;set;}="Active"; public Result? Result {get;set;} }
