namespace RaceDayAPI.Models;
public class UserProfile { public int UserProfileId {get;set;} public int UserId {get;set;} public User? User {get;set;} public string? Bio {get;set;} public string? PhoneNumber {get;set;} public string? EmergencyContact {get;set;} public string? ProfileImageUrl {get;set;} }
