namespace RaceDayAPI.Models;
public class Result { public int ResultId {get;set;} public int EnrolmentId {get;set;} public Enrolment? Enrolment {get;set;} public TimeSpan? FinishTime {get;set;} public int? Position {get;set;} public int? AgeGroupPosition {get;set;} public bool DidNotFinish {get;set;} public string? Notes {get;set;} public DateTime RecordedAt {get;set;}=DateTime.UtcNow; }
