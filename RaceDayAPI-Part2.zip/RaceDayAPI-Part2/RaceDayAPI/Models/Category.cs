namespace RaceDayAPI.Models;
public class Category { public int CategoryId {get;set;} public int EventId {get;set;} public Event? Event {get;set;} public string Name {get;set;}=""; public decimal DistanceKm {get;set;} public int MinAge {get;set;}=16; public int MaxAge {get;set;}=100; public decimal EntryFee {get;set;} public ICollection<Enrolment> Enrolments {get;set;}=new List<Enrolment>(); }
